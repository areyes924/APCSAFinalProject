import java.util.ArrayList;

public class PossibleCities{
	private ArrayList<City> cities = new ArrayList<City>();

	public void clearCities(){
		cities = new ArrayList<City>();
	}

	public void addEasyCities(){
		cities.add(new City("Paris", "France", "Europe"));
		cities.add(new City("Moscow", "Russia", "Europe"));
		cities.add(new City("London", "UK", "Europe"));
		cities.add(new City("Rome", "Italy", "Europe"));
		cities.add(new City("Venice", "Italy", "Europe"));
		cities.add(new City("Madrid", "Spain", "Europe"));
		cities.add(new City("Barcelona", "Spain", "Europe"));
		cities.add(new City("Amsterdam", "Netherlands", "Europe"));


		cities.add(new City("New York City", "USA", "North America"));
		cities.add(new City("Los Angeles", "USA", "North America"));
		cities.add(new City("Miami", "USA", "North America"));
		cities.add(new City("Mexico City", "Mexico", "North America"));

		cities.add(new City("Rio De Janiero", "Brazil", "South America"));

		cities.add(new City("Cairo", "Egypt", "Africa"));

		cities.add(new City("Dubai", "United Arab Emirates", "Asian"));
		cities.add(new City("Tokyo", "Japan", "EastAsian"));
		cities.add(new City("Hong Kong", "China", "EastAsian"));
		cities.add(new City("Delhi", "India", "EastAsian"));
		cities.add(new City("Seoul", "Korea", "EastAsian"));
		cities.add(new City("Jakarta", "Indonesia", "EastAsian"));
		cities.add(new City("Singapore", "Singapore", "EastAsian"));


		cities.add(new City("Sydney", "Australia", "Oceania"));
    
	}

	public void addMediumCities(){
		cities.add(new City("Berlin", "Germany", "Europe"));
		cities.add(new City("Monaco", "Monaco", "Europe"));
		cities.add(new City("Istanbul", "Turkey", "Europe"));
		cities.add(new City("Vienna", "Austria", "Europe"));										
		cities.add(new City("Prague", "Czechia", "Europe"));
		cities.add(new City("Milan", "Italy", "Europe"));
		cities.add(new City("Geneva", "Switzerland", "Europe"));
		cities.add(new City("Lisbon", "Portugal", "Europe"));
		cities.add(new City("Dublin", "Ireland", "Europe"));
		cities.add(new City("Copenhagen", "Denmark", "Europe"));
		cities.add(new City("Oslo", "Norway", "Europe"));
		cities.add(new City("Saint Petersburg", "Russia", "Europe"));
		cities.add(new City("Kyiv", "Ukraine", "Europe"));
		
		cities.add(new City("Havana", "Cuba", "North America"));
		cities.add(new City("Chicago", "USA", "North America"));
		cities.add(new City("Philadelphia", "USA", "North America"));

		cities.add(new City("Buenos Aires", "Argentina", "South America"));
		cities.add(new City("Montevideo", "Uruguay", "South America"));
		cities.add(new City("Lima", "Peru", "South America"));
		cities.add(new City("Bogota", "Colombia", "South America"));
		cities.add(new City("Sao Paulo", "Brazil", "South America"));

		cities.add(new City("Marrakesh", "Morocco", "Africa"));
		cities.add(new City("Tunis", "Tunisia", "Africa"));
		cities.add(new City("Lagos", "Nigeria", "Africa"));
		cities.add(new City("Mombasa", "Kenya", "Africa"));
		cities.add(new City("Cape Town", "South Africa", "Africa"));

		cities.add(new City("Kyoto", "Japan", "EastAsian"));
		cities.add(new City("Busan", "Korea", "EastAsian"));
		cities.add(new City("Beijing", "China", "EastAsian"));
		cities.add(new City("Bangkok", "Thailand", "EastAsian"));
		cities.add(new City("Dhaka", "Bangladesh", "EastAsian"));
		
		cities.add(new City("Auckland", "New Zealand", "Oceania"));
	}

	public void addHardCities(){
		
		addEuropeanCities();
		addAmericanCities();
		addEastAsianCities();
		addSouthAsianCities();
		addArabicCities();
		addLatinAmericanCities();
		addAfricanCities();
		addOceaniaCities();
		
	}

	public void addEuropeanCities(){
		cities.add(new City("Munich", "Germany", "Europe"));
		cities.add(new City("Frankfurt", "Germany", "Europe"));
		cities.add(new City("Hamburg", "Germany", "Europe"));
		cities.add(new City("Berlin", "Germany", "Europe"));
		cities.add(new City("Hanover", "Germany", "Europe"));

		cities.add(new City("Marseille", "France", "Europe"));
		cities.add(new City("Nantes", "France", "Europe"));
		cities.add(new City("Lyon", "France", "Europe"));
		cities.add(new City("Toulouse", "France", "Europe"));
		cities.add(new City("Paris", "France", "Europe"));

		cities.add(new City("Porto", "Portugal", "Europe"));
		cities.add(new City("Lisbon", "Portugal", "Europe"));
		
		cities.add(new City("Seville", "Spain", "Europe"));
		cities.add(new City("Valencia", "Spain", "Europe"));
		cities.add(new City("Bilbao", "Spain", "Europe"));
		cities.add(new City("Palma", "Spain", "Europe"));
		cities.add(new City("Barcelona", "Spain", "Europe"));
		cities.add(new City("Madrid", "Spain", "Europe"));
		
		cities.add(new City("Rome", "Italy", "Europe"));
		cities.add(new City("Milan", "Italy", "Europe"));
		cities.add(new City("Naples", "Italy", "Europe"));
		cities.add(new City("Turin", "Italy", "Europe"));
		cities.add(new City("Genoa", "Italy", "Europe"));
		cities.add(new City("Bologna", "Italy", "Europe"));
		cities.add(new City("Florence", "Italy", "Europe"));
		cities.add(new City("Palermo", "Italy", "Europe"));

		cities.add(new City("Zurich", "Switzerland", "Europe"));
		cities.add(new City("Bern", "Switzerland", "Europe"));
		cities.add(new City("Geneva", "Switzerland", "Europe"));
		
		cities.add(new City("Brussels", "Belgium", "Europe"));
		cities.add(new City("Antwerp", "Belgium", "Europe"));
		
		cities.add(new City("Manchester", "UK", "Europe"));
		cities.add(new City("Liverpool", "UK", "Europe"));
		cities.add(new City("Edinburgh", "UK", "Europe"));
		cities.add(new City("London", "UK", "Europe"));
		cities.add(new City("Birmingham", "UK", "Europe"));

		cities.add(new City("Copenhagen", "Denmark", "Europe"));
		cities.add(new City("Aarhus", "Denmark", "Europe"));
				
		cities.add(new City("Stockholm", "Sweden", "Europe"));
		cities.add(new City("Gothenburg", "Sweden", "Europe"));
		
		cities.add(new City("Bergen", "Norway", "Europe"));
		cities.add(new City("Oslo", "Norway", "Europe"));

		cities.add(new City("Helsinki", "Finland", "Europe"));

		cities.add(new City("Warsaw", "Poland", "Europe"));
		cities.add(new City("Krakow", "Poland", "Europe"));
		cities.add(new City("Gdansk", "Poland", "Europe"));

		cities.add(new City("Vienna", "Austria", "Europe"));
		cities.add(new City("Salzburg", "Austria", "Europe"));
		cities.add(new City("Innsbruck", "Austria", "Europe"));

		cities.add(new City("Prague", "Czechia", "Europe"));
		cities.add(new City("Brno", "Czechia", "Europe"));

		cities.add(new City("Bratislava", "Slovakia", "Europe"));
		
		cities.add(new City("Budapest", "Hungary", "Europe"));
		
		cities.add(new City("Zagreb", "Croatia", "Europe"));
		cities.add(new City("Sarajevo", "Bosnia", "Europe"));
		cities.add(new City("Belgrade", "Serbia", "Europe"));
		cities.add(new City("Tirana", "Albania", "Europe"));

		cities.add(new City("Athens", "Greece", "Europe"));
		cities.add(new City("Thessaloniki", "Greece", "Europe"));
		cities.add(new City("Naxos", "Greece", "Europe"));

		cities.add(new City("Nicosia", "Cyprus", "Europe"));
		
		// cities.add(new City("Ioannina", "Greece", "Europe"));
		
		cities.add(new City("Sofia", "Bulgaria", "Europe"));
		cities.add(new City("Varna", "Bulgaria", "Europe"));
		cities.add(new City("Plovdiv", "Bulgaria", "Europe"));
		
		cities.add(new City("Bucharest", "Romania", "Europe"));
		cities.add(new City("Timisoara", "Romania", "Europe"));
		cities.add(new City("Chisinau", "Moldova", "Europe"));
		
	}
	public void addAmericanCities(){
		cities.add(new City("New York City", "USA", "North America"));
		cities.add(new City("Philadelphia", "USA", "North America"));
		cities.add(new City("Boston", "USA", "North America"));
		cities.add(new City("Baltimore", "USA", "North America"));
		cities.add(new City("Chicago", "USA", "North America"));
		cities.add(new City("Cleveland", "USA", "North America"));
		cities.add(new City("Detroit", "USA", "North America"));
		cities.add(new City("Milwaukee", "USA", "North America"));
		cities.add(new City("Miami", "USA", "North America"));
		cities.add(new City("Atlanta", "USA", "North America"));
		cities.add(new City("Charlotte", "USA", "North America"));
		cities.add(new City("Miami", "USA", "North America"));
		cities.add(new City("Orlando", "USA", "North America"));
		cities.add(new City("Dallas", "USA", "North America"));
		cities.add(new City("Minneapolis", "USA", "North America"));
		cities.add(new City("Los Angeles", "USA", "North America"));
		cities.add(new City("San Francisco", "USA", "North America"));
		cities.add(new City("Phoenix", "USA", "North America"));
		cities.add(new City("Salt Lake City", "USA", "North America"));
		cities.add(new City("Denver", "USA", "North America"));
		cities.add(new City("Milwaukee", "USA", "North America"));
		// cities.add(new City("", "USA", "North America"));
		// cities.add(new City("", "USA", "North America"));
		// cities.add(new City("Raleigh", "USA", "North America"));
		cities.add(new City("Houston", "USA", "North America"));
		// cities.add(new City("Camden New Jersey", "USA", "North America"));
		cities.add(new City("Toronto", "Canada", "North America"));
		cities.add(new City("Vancouver", "Canada", "North America"));
		cities.add(new City("Quebec City", "Canada", "North America"));
		cities.add(new City("Ottawa", "Canada", "North America"));
		
	}
	public void addEastAsianCities(){
		cities.add(new City("Tokyo", "Japan", "East Asian"));
		cities.add(new City("Kyoto", "Japan", "East Asian"));
		cities.add(new City("Osaka", "Japan", "East Asian"));
		cities.add(new City("Yokohama", "Japan", "East Asian"));

		cities.add(new City("Seoul", "South Korea", "East Asian"));
		cities.add(new City("Busan", "South Korea", "East Asian"));
		cities.add(new City("Incheon", "South Korea", "East Asian"));
		
		cities.add(new City("Beijing", "China", "East Asian"));
		cities.add(new City("Hong Kong", "China", "East Asian"));
		cities.add(new City("Shanghai", "China", "East Asian"));
		cities.add(new City("Guangzhou", "China", "East Asian"));
		cities.add(new City("Chongqing", "China", "East Asian"));
		cities.add(new City("Hangzhou", "China", "East Asian"));
		cities.add(new City("Xi'An", "China", "East Asian"));

		cities.add(new City("Taipei", "Taiwan", "East Asian"));
		cities.add(new City("Kaohsiung", "Taiwan", "East Asian"));

		cities.add(new City("Manila", "Phillipines", "East Asian"));
		cities.add(new City("Quezon City", "Phillipines", "East Asian"));
	}

	public void addSouthAsianCities(){
		cities.add(new City("Kuala Lumpur", "Malaysia", "South Asia"));
		
		cities.add(new City("Singapore", "Singapore", "South Asia"));

		cities.add(new City("Jakarta", "Indonesia", "South Asia"));
		cities.add(new City("Surabaya", "Indonesia", "South Asia"));
		cities.add(new City("Bandung", "Indonesia", "South Asia"));

		cities.add(new City("Hanoi", "Vietnam", "South Asia"));
		cities.add(new City("Ho Chi Minh City", "Vietnam", "South Asia"));

		cities.add(new City("Phnom Penh", "Cambodia", "South Asia"));
		
		cities.add(new City("Bangkok", "Thailand", "South Asia"));
		
		cities.add(new City("Vientaine", "Laos", "South Asia"));
		cities.add(new City("Mandalay", "Myanmar", "South Asia"));
		
		cities.add(new City("Delhi", "India", "South Asia"));
		cities.add(new City("Mumbai", "India", "South Asia"));
		cities.add(new City("Hyderabad", "India", "South Asia"));

		cities.add(new City("Kathmandu", "Nepal", "South Asia"));
		cities.add(new City("Dhaka", "Bangladesh", "South Asia"));
		cities.add(new City("Colombo", "Sri Lanka", "South Asia"));
	}

	public void addArabicCities(){
		cities.add(new City("Kabul", "Afghanistan", "Arabic"));
		
		cities.add(new City("Islamabad", "Pakistan", "Arabic"));
		cities.add(new City("Karachi", "Pakistan", "Arabic"));
		
		cities.add(new City("Tehran", "Iran", "Arabic"));
		cities.add(new City("Isfahan", "Iran", "Arabic"));
		
		
		cities.add(new City("Baghdad", "Iraq", "Arabic"));
		cities.add(new City("Basrah", "Iraq", "Arabic"));

		cities.add(new City("Damascus", "Syria", "Arabic"));
		cities.add(new City("Aleppo", "Syria", "Arabic"));
		
		cities.add(new City("Dubai", "UAE", "Arabic"));
		cities.add(new City("Abu Dhabi", "UAE", "Arabic"));

		cities.add(new City("Muscat", "Oman", "Arabic"));
		cities.add(new City("Sana'a", "Yemen", "Arabic"));

		cities.add(new City("Amman", "Jordan", "Arabic"));

		cities.add(new City("Riyadh", "Saudi Arabia", "Arabic"));
		

		cities.add(new City("Cairo", "Egypt", "Arabic"));
		cities.add(new City("Alexandria", "Egypt", "Arabic"));

		cities.add(new City("Tripoli", "Libya", "Arabic"));
		cities.add(new City("Tunis", "Tunisia", "Arabic"));
		cities.add(new City("Algiers", "Algeria", "Arabic"));
		cities.add(new City("Marrakesh", "Morocco", "Arabic"));
		cities.add(new City("Rabat", "Morocco", "Arabic"));
		cities.add(new City("Casablanca", "Morocco", "Arabic"));
		
		
		
		
	}
	
	public void addLatinAmericanCities(){
		cities.add(new City("Mexico City", "Mexico", "Latin America"));
		cities.add(new City("Guadalajara", "Mexico", "Latin America"));

		cities.add(new City("Guatemala City", "Guatemala", "Latin America"));

		cities.add(new City("Havana", "Cuba", "Latin America"));
		cities.add(new City("Santo Domingo", "Dominican Republic", "Latin America"));
		cities.add(new City("Port au Prince", "Haiti", "Latin America"));

		cities.add(new City("Panama City", "Panama", "Latin America"));

		cities.add(new City("Caracas", "Venezuela", "Latin America"));
		
		cities.add(new City("Medellin", "Colombia", "Latin America"));
		cities.add(new City("Bogota", "Colombia", "Latin America"));
		
		cities.add(new City("Quito", "Ecuador", "Latin America"));
		
		cities.add(new City("Lima", "Peru", "Latin America"));

		cities.add(new City("La Paz", "Bolivia", "Latin America"));
		
		cities.add(new City("Asuncion", "Paraguay", "Latin America"));
		
		cities.add(new City("Rio de Janiero", "Brazil", "Latin America"));
		cities.add(new City("Manaus", "Brazil", "Latin America"));
		cities.add(new City("Brasilia", "Brazil", "Latin America"));
		cities.add(new City("Sao Paolo", "Brazil", "Latin America"));

		cities.add(new City("Santiago", "Chile", "Latin America"));
		
		cities.add(new City("Mendoza", "Argentina", "Latin America"));
		cities.add(new City("Buenos Aires", "Argentina", "Latin America"));
		cities.add(new City("Rosario", "Argentina", "Latin America"));
		
		cities.add(new City("Montevideo", "Uruguay", "Latin America"));
		
	}
	public void addAfricanCities(){
		cities.add(new City("Accra", "Ghana", "Africa"));
		cities.add(new City("Lagos", "Nigeria", "Africa"));
		cities.add(new City("Dakar", "Senegal", "Africa"));
		cities.add(new City("Bamako", "Mali", "Africa"));
		cities.add(new City("Addis Ababa", "Ethiopia", "Africa"));
		cities.add(new City("Khartoum", "Sudan", "Africa"));
		cities.add(new City("Mogadishu", "Somalia", "Africa"));
		cities.add(new City("Accra", "Ghana", "Africa"));
		cities.add(new City("Mombasa", "Kenya", "Africa"));
		cities.add(new City("Dar es Salaam", "Tanzania", "Africa"));
		cities.add(new City("Zanzibar", "Tanzania", "Africa"));
		cities.add(new City("Bangui", "CAR", "Africa"));
		cities.add(new City("Kinshasha", "DRC", "Africa"));
		cities.add(new City("Brazzaville", "Congo", "Africa"));
		cities.add(new City("Antananarivo", "Madagascar", "Africa"));
		cities.add(new City("Harare", "Zimbabwe", "Africa"));
		cities.add(new City("Johanessburg", "South Africa", "Africa"));
		cities.add(new City("Pretoria", "South Africa", "Africa"));
		cities.add(new City("Cape Town", "South Africa", "Africa"));
		
		
		
	}
	public void addOceaniaCities(){
		cities.add(new City("Sydney", "Australia", "Oceania"));
		cities.add(new City("Canberra", "Australia", "Oceania"));
		cities.add(new City("Brisbane", "Australia", "Oceania"));
		cities.add(new City("Adelaide", "Australia", "Oceania"));
		cities.add(new City("Perth", "Australia", "Oceania"));
		
		cities.add(new City("Auckland", "New Zealand", "Oceania"));
		cities.add(new City("Wellington", "New Zealand", "Oceania"));
		
		
	}

	
	
  	public void addCustomCity(City custom) {
    cities.add(custom);
  }
  
	public ArrayList<City> getCities(){
		return cities;
	}
	
	public City getCityOnContinent(String continent, int percentage, ArrayList<City> exclude){
		City returnable;
		int counter = 0;

		String similarContinent;

		if (continent.equals("North America")){
			similarContinent = "Europe";
		}
		else if (continent.equals("Europe")){
			similarContinent = "North America";
		}
		else if (continent.equals("East Asia")){
			similarContinent = "South Asia";
		}
		else if (continent.equals("South Asia")){
			similarContinent = "Arabic";
		}
		else if (continent.equals("Latin America")){
			similarContinent = "Europe";
		}
		else if (continent.equals("Arabic")){
			similarContinent = "South Asia";
		}
		else if (continent.equals("Africa")){
			similarContinent = "Oceania";
		}
		else if (continent.equals("Oceania")){
			similarContinent = "Africa";
		}
		else{
			similarContinent = "Europe";
		}
		
		while (true){
			returnable = getRandomCity(exclude);
			// If it's on the correct continent OR if it's on a similar continent and passes the percentage chance (percentage = 100 means that cities on similar continents will always be selected, and percentage = 0 means that cities on similar continents will never be selected)
			if (returnable.getContinent().equals(continent) || ((int)(Math.random() * 100) < percentage) && returnable.getContinent().equals(similarContinent)){
				return returnable;
			}
			counter ++;

			if (counter > 100){
				return null;
			}
		}	
		
	}

	public City getRandomCity(){
		return cities.get((int)(Math.random() * (cities.size())));
	}

	public City getRandomCity(ArrayList<City> exclude){
		boolean found = false;
		while (!found){
			City target = getRandomCity();

			boolean repeat = false;
			for (City c : exclude){
				if (c.getName().equals(target.getName())){
					// there's a problem
					repeat = true;
				}
			}

			if (!repeat){
				return target;
			}
		}

		return null;
	}
}