public class City{
	private String name;
	private String country;
	private String continent;
	
	public City(String name, String country, String continent){
		this.name = name;
		this.country = country;
		this.continent = continent;
	}

	public String getName(){
		return name;
	}
	public String getCountry(){
		return country;
	}
	public String getContinent(){
		return continent;
	}
}