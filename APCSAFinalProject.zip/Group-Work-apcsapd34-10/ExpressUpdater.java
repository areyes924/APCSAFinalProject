public class ExpressUpdater {
  private int quesCount;
  private String diffLevel;
  private String lastCity;
  private int numWrong;
  private int numCorrect;
  private String lastCountry;
  
  public ExpressUpdater(String s) { 
    diffLevel = s; 
  }
  
  public void incQC() { 
    quesCount++;
  }
  
  public int getQC() { 
    return quesCount; 
  }
  
  public String getDL() { 
    return diffLevel; 
  }

  public void setLastCity(String s) {
    lastCity = s;
  }

  public String getLastCity() {
    return lastCity;
  }

  public void setLastCountry(String s) {
    lastCountry = s;
  }

  public String getLastCountry() {
    return lastCountry;
  }

  public void incNumWrong() {
    numWrong++;
  }

  public void incNumCorrect() {
    numCorrect++;
  }
  
  public int getNumWrong() {
    return numWrong;
  }

  public int getNumCorrect() {
    return numCorrect;
  }

  public double getPercentage() {
    return 100 * ((double) (numCorrect) / (double) quesCount);
  }
  
}