public class Main {
	public static void main(String[] args) throws Exception {
		Guesser g = new Guesser();
		g.play();
	} 
}