import java.net.MalformedURLException;
import java.util.ArrayList;
import java.awt.BorderLayout;
import java.awt.Image;
import java.net.URL;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.Border;
import java.lang.Thread;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class Guesser implements ActionListener {
  static JFrame frame;
  static JFrame newFrame;
  static JFrame correctFrame;
  static JFrame endFrame;
  static ExpressUpdater updater;
  static Image image;
  static Image globalImage;
  static String globalString = "";
  
	public Guesser(){
		
	}
  
	PossibleCities cities = new PossibleCities();

	public void play() throws MalformedURLException , IOException {
    try {
		// Set Nimbus Look and Feel
  UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (Exception e) {
				e.printStackTrace();
		}

    UIManager.put("Panel.background", Color.decode("#010101"));

    // INITIALIZE TITLE SCREEN FRAME
    
		frame = new JFrame();
		frame.setSize(640, 480);
    frame.setLayout(new BorderLayout());
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH); 
		frame.setUndecorated(true);
		frame.setVisible(true);

    // CREATE BACKGROUND FROM SPACEBG IMAGE AND ADD IT TO FRAME

		JLabel background = new JLabel(new ImageIcon(new ImageIcon(getClass().getResource("spacebg.png")).getImage().getScaledInstance(frame.getWidth(), frame.getHeight(), Image.SCALE_SMOOTH)));

    background.setLayout(new BoxLayout(background, BoxLayout.Y_AXIS));
    frame.add(background);

    // CREATE THE DIFFERENT TEXT AND LABELS
          
    JLabel welcomeText = new JLabel("Welcome to the city guessing game!");
    welcomeText.setAlignmentX(Component.CENTER_ALIGNMENT);
    
    JLabel diffText = new JLabel("Select a difficulty.");
    diffText.setAlignmentX(Component.CENTER_ALIGNMENT);
    
    welcomeText.setForeground(Color.WHITE);
    diffText.setForeground(Color.WHITE);
    
    background.add(welcomeText);
    background.add(diffText);

    // CREATE A BUTTON PANEL FOR THE DIFFICULTY BUTTONS

    JPanel buttonPanel = new JPanel();
    buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
    background.add(buttonPanel);

    // CREATE BUTTONS
    
    JButton easyButton = new JButton("Easy");
    easyButton.setActionCommand("Easy");
    easyButton.addActionListener(this);

    JButton medButton = new JButton("Medium");
    medButton.setActionCommand("Medium");
    medButton.addActionListener(this);

		JButton hardButton = new JButton("Hard");
    hardButton.setActionCommand("Hard");
    hardButton.addActionListener(this);

    // ADD BUTTONS

    Font currentFont = new Font("Dialog", Font.BOLD, 25);
    Font smallFont = new Font("Dialog", Font.BOLD, 10);
    easyButton.setFont(currentFont);
    medButton.setFont(currentFont);
    hardButton.setFont(currentFont);
    welcomeText.setFont(currentFont);
    diffText.setFont(currentFont);

    // CREATE TEXT, BUTTONS, & PANEL FOR REGION SELECTION

    JLabel altSelectionText = new JLabel("Alternatively, you can play by region.");
    altSelectionText.setFont(currentFont);
    altSelectionText.setForeground(Color.WHITE);
    altSelectionText.setAlignmentX(Component.CENTER_ALIGNMENT);
    background.add(altSelectionText);

    JPanel buttonPanel2 = new JPanel();
    buttonPanel2.setLayout(new BoxLayout(buttonPanel2, BoxLayout.X_AXIS));
    
    background.add(buttonPanel2);
    
    JButton namerButton = new JButton("USA/Canada");
    namerButton.setActionCommand("USA");
    namerButton.addActionListener(this);
    
    JButton samerButton = new JButton("Latin America");
    samerButton.setActionCommand("SA");
    samerButton.addActionListener(this);

    JButton euButton = new JButton("Europe");
    euButton.setActionCommand("Europe");
    euButton.addActionListener(this);

		JButton asiaButton = new JButton("Asia");
    asiaButton.setActionCommand("Asia");
    asiaButton.addActionListener(this);

    JButton afmeButton = new JButton("Africa & Middle East");
    afmeButton.setActionCommand("AfME");
    afmeButton.addActionListener(this);

    namerButton.setFont(smallFont);
    samerButton.setFont(smallFont);
    euButton.setFont(smallFont);
    asiaButton.setFont(smallFont);
    afmeButton.setFont(smallFont);

    // CREATE GAPS BETWEEN THE BUTTONS
    
    // JPanel p = new JPanel();
    buttonPanel.add(Box.createRigidArea(new Dimension(40, 0))); // Adds a rigid gap of 10 pixels
    buttonPanel.add(easyButton);
    buttonPanel.add(Box.createRigidArea(new Dimension(40, 0))); // Adds a rigid gap of 10 pixels
    buttonPanel.add(medButton);
    buttonPanel.add(Box.createRigidArea(new Dimension(40, 0))); // Adds a rigid gap of 10 pixels 
		buttonPanel.add(hardButton);
    buttonPanel.add(Box.createRigidArea(new Dimension(40, 0))); // Adds a rigid gap of 10 pixels 

    // CREATE GAPS BETWEEN THE BUTTONS

    // JPanel p = new JPanel();
    buttonPanel2.add(Box.createRigidArea(new Dimension(15, 0))); // Adds a rigid gap of 10 pixels
    buttonPanel2.add(namerButton);
    buttonPanel2.add(Box.createRigidArea(new Dimension(15, 0))); // Adds a rigid gap of 10 pixels
    buttonPanel2.add(samerButton);
    buttonPanel2.add(Box.createRigidArea(new Dimension(15, 0))); // Adds a rigid gap of 10 pixels 
		buttonPanel2.add(euButton);
    buttonPanel2.add(Box.createRigidArea(new Dimension(15, 0))); // Adds a rigid gap of 10 pixels 
    buttonPanel2.add(asiaButton);
    buttonPanel2.add(Box.createRigidArea(new Dimension(15, 0))); // Adds a rigid gap of 10 pixels 
    buttonPanel2.add(afmeButton);
    buttonPanel2.add(Box.createRigidArea(new Dimension(15, 0))); // Adds a rigid gap of 10 pixels 
    frame.setVisible(true);
	}

  public void actionPerformed(ActionEvent e) {
    // LISTENS FOR BUTTON PRESSES
    // ADDS CITIES OR CLOSES/OPENS FRAMES APPROPRIATELY
    String s = e.getActionCommand();
    System.out.println(s);
    if (s.equals("Easy")) {
      cities.addEasyCities();
      updater = new ExpressUpdater("Easy");
      chooseNewImage();
    }
    if (s.equals("Medium")) {
      cities.addEasyCities();
      cities.addMediumCities();
      updater = new ExpressUpdater("Medium");
      chooseNewImage();
    }
    if (s.equals("Hard")) {
      cities.addHardCities();
      updater = new ExpressUpdater("Hard");
      chooseNewImage();
    }
    if (s.equals("USA")) {
      cities.addAmericanCities();
      updater = new ExpressUpdater("North America");
      chooseNewImage();
    }
    if (s.equals("SA")) {
      cities.addLatinAmericanCities();
      updater = new ExpressUpdater("Latin America");
      chooseNewImage();
    }
    if (s.equals("Asia")) {
      cities.addEastAsianCities();
      cities.addSouthAsianCities();
      updater = new ExpressUpdater("Asia");
      chooseNewImage();
    }
    if (s.equals("AfME")) {
      cities.addAfricanCities();
      cities.addArabicCities();
      updater = new ExpressUpdater("Africa & the Middle East");
      chooseNewImage();
    }
    if (s.equals("Europe")) {
      cities.addEuropeanCities();
      updater = new ExpressUpdater("Europe");
      chooseNewImage();
    }
    if (s.equals("Continue")) {
      correctFrame.dispose();
    }
    if (s.equals("End game")) {
      correctFrame.dispose();
      newFrame.dispose();
      createEndFrame();
    }
  }
  
	public void chooseNewImage(){
		// FIND CITY POSSIBILITIES BASED ON SELECTED OPTION

		ArrayList<City> selected = new ArrayList<City>();
		City option1;
		City option2;
		City option3;
		City option4;
		City targetCity;

		if (!updater.getDL().equals("Hard")){
			option1 = cities.getRandomCity(selected);
			selected.add(option1);
			option2 =  cities.getRandomCity(selected);
			selected.add(option2);
			option3 =  cities.getRandomCity(selected);
			selected.add(option3);
			option4 =  cities.getRandomCity(selected);
			selected.add(option4);
		} else{
			System.out.println("Special Hard Mode generation");
			int targetContinentGenerator = (int)(Math.random() * 100);
			String targetContinent;
			if (targetContinentGenerator < 15){
				targetContinent = "North America";
			}
			else if (targetContinentGenerator < 35){
				targetContinent = "Europe";
			}
			else if (targetContinentGenerator < 55){
				targetContinent = "East Asia";
			}
			else if (targetContinentGenerator < 65){
				targetContinent = "South Asia";
			}
			else if (targetContinentGenerator < 75){
				targetContinent = "Latin America";
			}
			else if (targetContinentGenerator < 85){
				targetContinent = "Arabic";
			}
			else if (targetContinentGenerator < 95){
				targetContinent = "Africa";
			}
			else{
				targetContinent = "Oceania";
			}
			option1 = cities.getCityOnContinent(targetContinent, 60, selected);
			selected.add(option1);
			option2 =  cities.getCityOnContinent(targetContinent, 60, selected);
			selected.add(option2);
			option3 =  cities.getCityOnContinent(targetContinent, 60, selected);
			selected.add(option3);
			option4 =  cities.getCityOnContinent(targetContinent, 60, selected);
			selected.add(option4);
		}

		// SELECT CITY FROM ARRAYLIST TO BE TARGET
		targetCity = selected.get((int)(Math.random() * 4));
    
		// GET URL FOR IMAGE BY GETTING CITY NAME AND APPENDING "STREET VIEW"
		URL url = null;
		try {
			url = urlFinder(replaceSpacesWithPlus(targetCity.getName()) + "+Street+View");
		} catch (IOException exception) {
			System.out.println("url error");
		}

    // SET IMAGE TO URL
  	image = null;
  	try {
  		image = ImageIO.read(url); 
  	} catch (IOException exception) {
  		System.out.println("url error");
  	}

    // RESIZE IMAGE
  	Image resizedImage = image.getScaledInstance(-1, 480, Image.SCALE_SMOOTH);
    image = resizedImage;
//    globalImage = resizedImage;
    globalImage = image;

    // SET TITLE SCREEN TO BE INVISIBLE
  	frame.setVisible(false);

    // MAKE NEW FRAME WITH THE 4 ANSWER CHOICES
  	newFrame = new JFrame();
  	newFrame.setSize(640, 480);
  	newFrame.setLayout(new BorderLayout()); 
    newFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
    newFrame.setUndecorated(true);
    newFrame.setVisible(true);

  	newFrame.setLayout(new BorderLayout());
  
  	JLabel background = new JLabel(new ImageIcon(resizedImage));
  	newFrame.add(background);
  	background.setLayout(new FlowLayout());
  
  	JButton button1 = new JButton(new SelectCity(option1.getName(), targetCity));
  	background.add(button1);
  	JButton button2 = new JButton(new SelectCity(option2.getName(), targetCity));
  	background.add(button2);
  	JButton button3 = new JButton(new SelectCity(option3.getName(), targetCity));
  	background.add(button3);
  	JButton button4 = new JButton(new SelectCity(option4.getName(), targetCity));
  	background.add(button4);
  	newFrame.setVisible(true); 
	}

	public class SelectCity extends AbstractAction {
    // DEPENDING ON BUTTON PRESS, INCREMENTS EITHER "WRONG" OR "CORRECT" QUESTION COUNT IN UPDATER, SETS GLOBAL STRING TO EITHER OF THE TWO, AND INITIALIZES THE RESULTS FRAME
		String cityGuessed;
		City targetCity;
		public SelectCity(String text, City targetCity){
			super(text);
			cityGuessed = text;
			this.targetCity = targetCity;
		}
   
    public void actionPerformed(ActionEvent e) {
      updater.incQC();
      updater.setLastCity(targetCity.getName());
      updater.setLastCountry(targetCity.getCountry());
      
      System.out.println("qc: " + updater.getQC());
      
      if (cityGuessed.equals(targetCity.getName())){
        globalString = "Correct";
				System.out.println("Correct!");
        updater.incNumCorrect();
        createResultsFrame();
			}
			else{
        globalString = "Wrong";
				System.out.println("Wrong. The correct answer was " + targetCity.getName());
        updater.incNumWrong();
        createResultsFrame();
			}
      newFrame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
      

      chooseNewImage();
    }
	}

  public void createResultsFrame() {
    // SET UP CORRECT/WRONG FRAME
    // THIS FRAME ESSENTIALLY JUST SHOWS THE QUESTION NUMBER, WHETHER THE PREVIOUS ONE WAS RIGHT OR WRONG (DEPENDING ON GLOBAL VARIABLES), AND HAS 2 BUTTONS TO EITHER CONTINUE OR END THE GAME
    // CONTINUING DESTROYS THIS FRAME (IT GETS RECREATED AFTER EVERY QUESTION), AND ENDING DESTROYS BOTH IT AND THE QUESTION FRAME AND INITIALIZES THE END FRAME
    // THESE BUTTON PRESSES ARE HANDED IN THE [public void actionPerformed(ActionEvent e)] METHOD ABOVE
    URL url = null;
    url = Guesser.class.getResource("1x1.png");
		
    correctFrame = new JFrame();
    correctFrame.setSize(640,480);
		correctFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
    correctFrame.setUndecorated(true);
    correctFrame.setVisible(true);
    JLabel correctBG = new JLabel(new ImageIcon(globalImage));
	  correctFrame.add(correctBG);
    correctBG.setLayout(new BoxLayout(correctBG, BoxLayout.Y_AXIS));
    correctFrame.add(correctBG);

    Font thisFont = new Font("Dialog", Font.BOLD, 25);
    Font smallerFont = new Font("Dialog", Font.BOLD, 22);
    
    JLabel correctOrWrongBlack = new JLabel(globalString);
    correctOrWrongBlack.setFont(thisFont);
    if (globalString.equals("Correct")) {
      correctOrWrongBlack.setForeground(Color.GREEN);
    } else {
      correctOrWrongBlack.setForeground(Color.RED);
    }
    
    correctOrWrongBlack.setAlignmentX(Component.CENTER_ALIGNMENT);
      
    correctBG.add(correctOrWrongBlack);
    JPanel textPanel1 = new JPanel();
    textPanel1.setLayout(new BoxLayout(textPanel1, BoxLayout.X_AXIS));
    JPanel textPanel2 = new JPanel();
    textPanel2.setLayout(new BoxLayout(textPanel2, BoxLayout.X_AXIS));
    JPanel textPanel3 = new JPanel();
    textPanel3.setLayout(new BoxLayout(textPanel3, BoxLayout.X_AXIS));
    JLabel questionCount = new JLabel("Question number: " + updater.getQC());
    questionCount.setFont(thisFont);
    questionCount.setAlignmentX(Component.CENTER_ALIGNMENT);
    questionCount.setForeground(Color.WHITE);
    textPanel1.add(questionCount);
    
    JLabel correctCity = new JLabel("The city was "  + updater.getLastCity());
    correctCity.setFont(thisFont);
    correctCity.setAlignmentX(Component.CENTER_ALIGNMENT);
    correctCity.setForeground(Color.WHITE);
    textPanel2.add(correctCity);
    
    JLabel inCountry = new JLabel("which is in "  + updater.getLastCountry());
    inCountry.setFont(thisFont);
    inCountry.setAlignmentX(Component.CENTER_ALIGNMENT);
    inCountry.setForeground(Color.WHITE);
    textPanel3.add(inCountry);
    
    correctBG.add(textPanel1);
    correctBG.add(textPanel2);
    correctBG.add(textPanel3);

    JButton continueButton = new JButton("Continue");
    continueButton.setActionCommand("Continue");
    continueButton.addActionListener(this);
    continueButton.setAlignmentX(Component.CENTER_ALIGNMENT);
    JButton endButton = new JButton("End game");
    endButton.setActionCommand("End game");
    endButton.addActionListener(this);
    endButton.setAlignmentX(Component.CENTER_ALIGNMENT);

    correctBG.add(continueButton);
    correctBG.add(endButton);

    continueButton.setFont(thisFont);
    endButton.setFont(smallerFont);
    
    correctFrame.setAlwaysOnTop(true);
    correctFrame.setVisible(true);
  }

  public void createEndFrame() {
    // SET UP THE WINDOW AT THE END OF THE GAME
    // SHOWS A RESULTS SCREEN WITH DIFFICULTY OR REGION (WHOSE COLOR IS SET DEPENDING ON THIS), A PERCENTAGE USING VARIABLES STORED IN THE UPDATER, AND GOOD JOB IF A SCORE OF 100% IS ATTAINED
    
    URL url = null;
    url = Guesser.class.getResource("spacebg.png");
    try {
		  image = ImageIO.read(url); 
    } catch (IOException exception) {
      System.out.println("url error");
    }

    UIManager.put("Panel.background", Color.decode("#010101"));
    
    endFrame = new JFrame();
    endFrame.setSize(640,480);
		endFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
    endFrame.setUndecorated(true);
    endFrame.setVisible(true);
    JLabel endBG = new JLabel(new ImageIcon(image));

    endBG.setLayout(new BoxLayout(endBG, BoxLayout.Y_AXIS));
    endFrame.add(endBG);

    JPanel textPanel = new JPanel();
    textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.X_AXIS));

    Font bigFont = new Font("Dialog", Font.BOLD, 25);
    Font smallerFont = new Font("Dialog", Font.BOLD, 18);
    
    JLabel gameOverLabel = new JLabel("The game is over!");
    gameOverLabel.setForeground(Color.WHITE);
    gameOverLabel.setFont(bigFont);
    gameOverLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

    JLabel difficultyLabel = null;
    if (updater.getDL().equals("Easy") || updater.getDL().equals("Medium") || updater.getDL().equals("Hard")){
      if (updater.getDL().equals("Easy")) {
        difficultyLabel = new JLabel("You played on the easy difficulty.");
        difficultyLabel.setForeground(Color.GREEN);
      }
      if (updater.getDL().equals("Medium")) {
        difficultyLabel = new JLabel("You played on the medium difficulty.");
        difficultyLabel.setForeground(Color.ORANGE);
      }
      if (updater.getDL().equals("Hard")) {
        difficultyLabel = new JLabel("You played on the hard difficulty.");
        difficultyLabel.setForeground(Color.RED);
      }
    } else {
      difficultyLabel = new JLabel("You played in the region of " + updater.getDL() + ".");
      difficultyLabel.setForeground(Color.WHITE);
    }
    difficultyLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
    difficultyLabel.setFont(smallerFont);
    
    JLabel totQuP1 = new JLabel("Out of " + updater.getQC() + " questions, you got ");
    JLabel numWrong = new JLabel("" + updater.getNumWrong());
    JLabel totQuP2 = new JLabel(" wrong.");
    totQuP1.setForeground(Color.WHITE);
    numWrong.setForeground(Color.RED);
    totQuP2.setForeground(Color.WHITE);
    
    totQuP1.setFont(smallerFont);
    numWrong.setFont(smallerFont);
    totQuP2.setFont(smallerFont);

    textPanel.add(totQuP1);
    textPanel.add(numWrong);
    textPanel.add(totQuP2);

    textPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

    String percentage = updater.getPercentage() + "";
    if (percentage.length() > 5) {
      percentage = percentage.substring(0,6);
    }
    JLabel percentageLabel = new JLabel("This is equivalent to a score of " + percentage + " %.");
    percentageLabel.setForeground(Color.WHITE);
    percentageLabel.setFont(smallerFont);
    percentageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

    JLabel finalLabel = null;
    if (updater.getPercentage() >= 100) {
      finalLabel = new JLabel("Great job and thank you for playing!");
    } else {
      finalLabel = new JLabel("Thank you for playing!");
    }
    finalLabel.setForeground(Color.decode("#ffff99"));
    finalLabel.setFont(bigFont);
    finalLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
    
    endBG.add(gameOverLabel);
    endBG.add(difficultyLabel);
    endBG.add(textPanel);
    endBG.add(percentageLabel);
    endBG.add(finalLabel);

    endFrame.setVisible(true);
  }
	
  public static URL urlFinder(String prompt) throws MalformedURLException {
    // THIS METHOD USES A GOOGLE SEARCH API KEY TO SEARCH GOOGLE IMAGES AND GET A RESULT IN THE FORM OF A JSON FILE, AFTER WHICH IT RETURNS THE URL OF THE IMAGE
    // THERE ARE 10 RESULTS PER QUERY AND IT PICKS ONE
    // IN THE CASE OF AN ERROR SUCH AS AN API KEY OVERLOAD IT RETURNS A PRE-SET IMAGE
    
		String SEARCH_API_URL = "https://www.googleapis.com/customsearch/v1";
		String API_KEY = "AIzaSyB__k352YPh7bLWMkACCSPHEOUF-LoE9bw" 
    /* alternative: "AIzaSyCtmfy2y48muXc4eC0gfffU99Nmcg7CYVA" */; 
    /* old: "AIzaSyAnLLyMWfxJ3fPXJcW50-mk8rUJJNf4mnU" */
    /* alternative 2:  AIzaSyB__k352YPh7bLWMkACCSPHEOUF-LoE9bw */
		String SEARCH_ENGINE_ID = "009b35221107940a2" 
    /* old: "22fe88f3e21c84a17" */;
    /* alternative: 009b35221107940a2 */
		int NUMBER_OF_RESULTS = 10;
		ArrayList<String> imageUrls = new ArrayList<>();
		try {
			URL url = new URL(SEARCH_API_URL + "?key=" + API_KEY + "&cx=" + SEARCH_ENGINE_ID +
							"&q=" + prompt + "&searchType=image&num=" + NUMBER_OF_RESULTS);
      
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("GET");
	
			BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			StringBuilder response = new StringBuilder();
			String line;
	
			while ((line = reader.readLine()) != null) {
					response.append(line);
			}
			reader.close();
	
			// Parse the JSON response
			String jsonResponse = response.toString();
			String[] items = jsonResponse.split("\"link\": \"");
	
			for (int i = 1; i < items.length; i++) {
					String imageUrl = items[i].split("\"")[0];
					imageUrls.add(imageUrl);
			}

		} 
		catch (IOException e) {
			e.printStackTrace();
		}

		if (!imageUrls.isEmpty()) {
			Random random = new Random();
			int randomIndex = random.nextInt(imageUrls.size());
			String randomImageUrl = imageUrls.get(randomIndex);;
			return new URL(randomImageUrl);
		}
		else {
			System.out.println("No image results found.");
			return new URL("https://t3.gstatic.com/licensed-image?q=tbn:ANd9GcTVEQa8Zq-vOCLDnqnS_utw_LagdV5KQoIA4eLXGvxpjv9KZF-oWc1dPTm0VsEZ5RyU");
		}
	}

  public String replaceSpacesWithPlus(String input) {
    // THIS METHOD HANDLES CITIES WITH NAMES THAT HAVE SPACES, ALLOWING THEM TO SHOW UP PROPERLY BUT BE SEARCHED FOR WITH THE SPACES REPLACED WITH PLUS SIGNS
    return input.replace(" ", "+");
  }

}